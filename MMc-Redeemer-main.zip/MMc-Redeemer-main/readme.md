# MMC Redeemer
## _The end of selling a overpriced redeemer._

Dear users in the community, speaking here, As you have known before, we have had some issues with the user called MMC. To this day, he has scammed multiple people out of hundreds, if not thousands of dollars. He is known for removing negative reviews and scamming slot owners to this day. Mr. Matthew (MMC) has zero coding knowledge, Claims that he has spent first 5000$ then 3000$ for his lifecord.io project (it's a fork of savecord.io) and his frontend is purchased from https://themeforest.net/item/bithu-nft-mintingcollection-wordpress-theme/39538006?s_rank=1.

## Revolutionary MMC Redeemer

How should I call it? A re-code of redeemer v2 or a skid of redeemer v2? That's the hard question. From simply looking at it, anyone who is able to read these days will see that there is close to no difference between aran's redeemer v2 and mmc's redeemer. But hey, let's talk about the CRAZY protection he used in his redeemer and even how Indians were able to crack it.
Honestly, all you needed to do is skip the auth process since it was loading from a different file. (Hey crazy dev, you can just use // to make your code readable, no need to use multiple files to do so.) The first crack was made by me (penk) and all it contained is 26 lines of code. Even after reporting it to mmc, he wasn't able to patch it (functions within python exist) and he was scared of me leaking the crack. A few months later, Indians cracked it and it was being sold for 2$ xD.

# Some cool info
I might want to start getting his British ass info leaked again. Remember, I don't live that far from Manchester, Matthew.
PS: https://discord.gg/supplierz will be selling the best redeemer on market once this gets patched ;)
